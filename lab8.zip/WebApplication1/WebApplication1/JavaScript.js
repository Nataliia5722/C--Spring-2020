﻿/*function () { 
    document.write("Hello");
    */
class A {

    func(id1, el1, id2, el2) {
        if (document.getElementById("matr").hasChildNodes() != 0)
        { document.getElementById("matr").innerHTML = ''; }
        let n = document.getElementById("n").value;

        this.create(id1, el1, n);
        this.create(id2, el2, n);
        this.f();
    }

    create(id, el, n) {
        var v;
        var d = document.createElement('div');
        var table = id + '<table>';

        if (n != 0) {
            for (var i = 0; i < n; i++) {
                table += '<tr>';
                for (var j = 0; j < n; j++) {
                    v = el + i + j;
                    table += '<td>' + '<input type="text" id="' + v + '" value="0">' + '</td>';
                }
                table += '</tr>';
            }
            table += '</table><br/>';
            var matr = document.getElementById("matr");
            d.innerHTML = table;
            matr.appendChild(d);
        }
    }

    f() {
        var k = '<input type="button" id ="multi" value = "Умножить" onclick="obj2.sum()">';
        var block = document.createElement('div');
        block.innerHTML = k;
        document.getElementById("matr").appendChild(block);
    }

}



class B {

    sum() {
        if (document.getElementById("rez").hasChildNodes() != 0)
        { document.getElementById("rez").innerHTML = ''; }
        let n = document.getElementById("n").value;
        var rez;
        var t;
        var table2 = '<br/><table>';
        for (var i = 0; i < n; i++) {
            table2 += '<tr>';
            for (var j = 0; j < n; j++) {
                t = 0;
                rez = "rez" + i + j;
                for (var r = 0; r < n; r++)
                    t += Number(document.getElementById("a" + i + r).value) * Number(document.getElementById("b" + r + j).value);
                table2 += '<td>' + '<input type="text" id="' + rez + '" value="' + t + '">' + '</td>';
            }
            table2 += '</tr>';
        }
        table2 += '</table><br/>';
        var div2 = document.getElementById('rez');
        var div = document.createElement('strong');
        div.innerHTML = table2;
        div2.appendChild(div);
    }


}